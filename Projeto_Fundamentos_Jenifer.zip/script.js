document.addEventListener("DOMContentLoaded", function () {
    const botao = document.getElementById("mensagemBtn");
    const mensagem = document.getElementById("mensagem");

    botao.addEventListener("click", function () {
        mensagem.textContent = "Você é capaz de conquistar tudo que desejar!";
    });
});